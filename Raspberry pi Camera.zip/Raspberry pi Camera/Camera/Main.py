import tkinter as tk
import os

window = tk.Tk()
window.title('Camera')
window.geometry('400x200')

def cap():
    os.system('python /home/pi/Camera/photo.py')
    
def vvv():
    os.system('python /home/pi/Camera/video5.py')
    
def vvvv():
    os.system('python /home/pi/Camera/video10.py')
    
b = tk.Button(window, 
    text='Capture',      # 显示在按钮上的文字
    width=10, height=2, 
    command=cap)     # 点击按钮式执行的命令
b.pack()    # 按钮位置

c = tk.Button(window, 
    text='Record 5 seconds',      # 显示在按钮上的文字
    width=20, height=2, 
    command=vvv)     # 点击按钮式执行的命令
c.pack()    # 按钮位置

d = tk.Button(window, 
    text='Record 10 seconds',      # 显示在按钮上的文字
    width=20, height=2, 
    command=vvvv)     # 点击按钮式执行的命令
d.pack()    # 按钮位置
    
window.mainloop()