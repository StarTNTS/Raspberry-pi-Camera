from picamera import PiCamera
import time

camera=PiCamera()
gt0=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())
gt='VID-'+gt0

camera.start_preview()
camera.start_recording('/home/pi/Desktop/Saves/{}.h264'.format(gt))
time.sleep(5)
camera.stop_recording()
camera.stop_preview()
camera.close()