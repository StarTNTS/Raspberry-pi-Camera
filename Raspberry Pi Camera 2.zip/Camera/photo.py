from picamera import PiCamera
import time

camera=PiCamera()
gt0=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())
gt='PIC-'+gt0

camera.start_preview()
time.sleep(3)
camera.capture('/home/pi/Desktop/Saves/{}.jpg'.format(gt))
camera.stop_preview()
camera.close()