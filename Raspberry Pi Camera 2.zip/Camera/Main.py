import tkinter as tk
import os
from picamera import PiCamera
import time
import sys


window = tk.Tk()
window.title('Camera')
window.geometry('400x200')





camera=PiCamera()
gt0=time.strftime('%Y-%m-%d %H:%M:%S',time.localtime())
gt='VID-'+gt0

def ente():
    inp=int(boxx.get())
    if 0<inp<60 :
        camera.start_preview()
        camera.start_recording('/home/pi/Desktop/Saves/{}.h264'.format(gt))
        camera.wait_recording(inp)
        camera.stop_recording()
        camera.stop_preview()
        camera.close()
    sys.exit()





def cap():
    os.system('python /home/pi/Camera/photo.py')
    
b = tk.Button(window, 
    text='Capture',      # 显示在按钮上的文字
    width=10, height=2, 
    command=cap)     # 点击按钮式执行的命令
b.pack()    # 按钮位置

e = tk.Label(window, 
    text='''
    
    Record freely Below
    ''',      # 显示在按钮上的文字
    width=20, height=2)     
e.pack()    # 按钮位置

haha=tk.Label(window,text='How long will the video be')
haha.pack()

boxx=tk.Entry(window,show=None,font=('Arial',14))
boxx.pack()

y = tk.Button(window, 
    text='Start to record!',      
    width=10, height=2, 
    command=ente)     
y.pack()
    
window.mainloop()